var app = angular.module('myapp',[]);

app.controller('myController', function($scope,$http){
    $scope.save = function(sub){
        console.log(sub)
        $http({
            method : 'POST',
            url : '/postsubmit',
            data : $scope.sub
    
    }).then(function success(response){
         alert('data uploaded');
         location.reload('/')
     },function error(response){
        alert('Error');
   
    })
    };
       
      
    });
app.controller('acontroller',function($scope,$http){
    $http({
        method : 'get',
        url : '/gettotaldata'
        }).then(function success(response){
         //alert('data uploaded');
         console.log(response.data)
         $scope.totaldata = response.data
     },function error(response){
        alert('Error');
   
    })
        $scope.condemned = function(datad){
        console.log(datad)
        $http({
            method : 'POST',
            url : '/postcondemned',
            data : datad
    
    }).then(function success(response){
         alert('data condemned');
         location.reload('/')
     },function error(response){
        alert('Error');
   
    })
    };
    $scope.transferdata = function(datad){
        console.log(datad)
        $http({
            method : 'POST',
            url : '/posttransfer',
            data : datad
    
    }).then(function success(response){
         alert('data transfered');
         location.reload('/')
     },function error(response){
        alert('Error');
   
    })
    };

   $scope.transfered = function(data){
    console.log(data)
    $scope.transfer = data
   }
   
})
app.controller('bcontroller',function($scope,$http){
    $http({
        method : 'get',
        url : '/getcondemneddata'
        }).then(function success(response){
         //alert('data uploaded');
         console.log(response.data)
         $scope.totaldata = response.data
     },function error(response){
        alert('Error');
   
    })
       
   
   
})
app.controller('ccontroller',function($scope,$http){
    $http({
        method : 'get',
        url : '/gettransfereddata'
        }).then(function success(response){
         //alert('data uploaded');
         console.log(response.data)
         $scope.totaldata = response.data
     },function error(response){
        alert('Error');
   
    })
       
   
   
})
app.controller('dcontroller',function($scope,$http){
    $http({
        method : 'get',
        url : '/getreceiveingdata'
        }).then(function success(response){
         //alert('data uploaded');
         console.log(response.data)
         $scope.totaldata = []
         var a = response.data
         for(var i = 0;i<a.length;i++){

            if(a[i].status1 == 'received'){
               console.log(a[i])
            }
            else{
                $scope.totaldata.push(a[i])
            }
         }
         //$scope.totaldata = response.data
     },function error(response){
        alert('Error');
   
    })
    $scope.received = function(datad){
        console.log(datad)
        $http({
            method : 'POST',
            url : '/postreceive',
            data : datad
    
    }).then(function success(response){
         alert('data received');
         location.reload('/')
     },function error(response){
        alert('Error');
   
    })
    };
   
   
   
})
app.controller('econtroller',function($scope,$http){
    $http({
        method : 'get',
        url : '/getreceiveddata'
        }).then(function success(response){
         //alert('data uploaded');
         console.log(response.data)
         $scope.totaldata = response.data
     },function error(response){
        alert('Error');
   
    })
      
   
   
})
app.controller('fcontroller',function($scope,$http){
    $http({
        method : 'get',
        url : '/getoveralldata'
        }).then(function success(response){
         //alert('data uploaded');
         console.log(response.data)
         $scope.totaldata = response.data
     },function error(response){
        alert('Error');
   
    })
      
   
   
})

    

