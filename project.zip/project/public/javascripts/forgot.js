var app = angular.module('forgotApp',[]);
app.controller('forgotController', function($scope,$http){
  

  $scope.save = function(forgot){
    $http({
    	method : 'POST',
        url : '/postforgot',
        data : $scope.forgot
    }).then(function success(response){
    	alert('Email Sent');
    }, function error(response){
        alert('Error');
    });
  }

});