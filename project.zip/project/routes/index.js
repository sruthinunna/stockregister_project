var express = require('express');
var router = express.Router();
var randomstring = require('randomstring')
var nodemailer = require('nodemailer')
var moment = require('moment')
var monk = require('monk')
var db = monk('localhost:27017/project');
//var collection = db.get('users');
var signup = db.get('signup');
var collection = db.get('totalstockdata')


/* GET home page. */

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


router.get('/contact',function(req,res){
	res.render('contact')
});


router.get('/login', function(req, res){
	res.render('login')
});
router.get('/forget', function(req, res){
	res.render('forget')
});

router.get('/page', function(req, res){
if(req.Session && req.Session.user){
    //console.log("working");
    console.log(req.Session.user);
    res.locals.user = req.Session.user
    res.render('page');
  }
  else{
    req.Session.reset();
    res.redirect('/login');
  }	
});
router.post('/postsubmit',function(req,res){
	if(req.Session && req.Session.user){

	console.log(req.body)
	var data = {
		user : req.Session.user.username,
		useremplyid:req.Session.user.employee_id,

		College : req.body.College,
		Department : req.body.Department,
		Labname : req.body.Labname,
		Itemname : req.body.Itemname,
		CostPerUnit : req.body.CostPerUnit,
		Quantity :req.body.Quantity,
		TotalCost : req.body.TotalCost,
		Remarks : req.body.Remarks,
		dateofreceipt: moment(req.body.dateofreceipt).format('DD-MM-YYYY'),
		Specifications : req.body.Specifications,
		status:'newdata'
	}
	collection.insert(data, function(err,docs){
    if(err){
    	console.log(err);
    }
    else{
    	//console.log(docs);
    	res.send(docs);
    }

  });
}

	
	
});
router.get('/gettotaldata',function(req,res){
	if(req.Session && req.Session.user){
		if(req.Session.user.username=="admin"){
		collection.find({status:'newdata'},function(err,docs){
		
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})	
		}
		else{
			collection.find({status:'newdata','user':req.Session.user.username,'useremplyid':req.Session.user.employee_id},function(err,docs){
		
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})

		}
	
}
})
router.get('/getcondemneddata',function(req,res){
	if(req.Session && req.Session.user){
		if(req.Session.user.username=="admin"){
			collection.find({status:'condemned'},function(err,docs){
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
		}
		else{
			collection.find({status:'condemned','user':req.Session.user.username,'useremplyid':req.Session.user.employee_id},function(err,docs){
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
		}
	
}

})
router.get('/gettransfereddata',function(req,res){
	if(req.Session && req.Session.user){
		if(req.Session.user.username=="admin"){
			collection.find({status:'transfered'},function(err,docs){
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
		}
		else{
			collection.find({status:'transfered','user':req.Session.user.username,'useremplyid':req.Session.user.employee_id},function(err,docs){
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
		}

	
}

})
router.get('/getreceiveingdata',function(req,res){
	if(req.Session && req.Session.user){
		//console.log('working')
		//console.log(req.Session.user)
		if(req.Session.user.username=="admin"){
			collection.find({status:'transfered','transfercollege':req.Session.user.college},function(err,docs){
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
		}
		else{
			collection.find({status:'transfered','transferdepartment':req.Session.user.department,'transfercollege':req.Session.user.college},function(err,docs){
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
		}
	
}

})
router.get('/getreceiveddata',function(req,res){
	if(req.Session && req.Session.user){
		//console.log('working')
		//console.log(req.Session.user)
		if(req.Session.user.username=="admin"){
			collection.find({status1:'received'},function(err,docs){
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
		}
		else{
			collection.find({status1:'received','transferdepartment':req.Session.user.department,'transfercollege':req.Session.user.college},function(err,docs){
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
		}
	
}

})
router.get('/getoveralldata',function(req,res){
	if(req.Session && req.Session.user){
		//console.log('working')
		//console.log(req.Session.user)
		if(req.Session.user.username=="admin"){
			collection.find({},function(err,docs){
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
		}
		else{
			collection.find({'user':req.Session.user.username,'useremplyid':req.Session.user.employee_id},function(err,docs){
		if(err){
			console.log(err);

		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
		}
	
}

})
router.post('/postcondemned',function(req,res){
	console.log(req.body)
	collection.update({"_id":req.body._id},{$set:{'status':'condemned','condemneddate':moment().format('DD-MM-YYYY')}},function(err,docs){
		if(err){
			console.log(err);
		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
})
router.post('/postreceive',function(req,res){
	if(req.Session && req.Session.user){
	//console.log(req.body)
	collection.update({"_id":req.body._id},{$set:{'status1':'received','receivedate':moment().format('DD-MM-YYYY'),'receiveduser':req.Session.user.username,'receiveduseremplyid':req.Session.user.employee_id}},function(err,docs){
		if(err){
			console.log(err);
		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
}
})

router.post('/posttransfer',function(req,res){
	console.log(req.body)
	collection.update({"_id":req.body._id},{$set:{'status':'transfered','transfereddate':moment(req.body.Transfereddate).format('DD-MM-YYYY'),'transferlab':req.body.TransferedLab,'transfercollege':req.body.Transferedcollege,'transferdepartment':req.body.TransferedDepartment}},function(err,docs){
		if(err){
			console.log(err);
		}
		else{
			//console.log(docs);
			res.send(docs);
		}
	})
})
router.post('/signup', function(req,res){
  signup.insert(req.body, function(err,docs){
  	var password = req.body.password;
  	var password1 = req.body.password1;
  	if (password == password1) {
  		res.redirect('/login');
  	}
   else{
   	 res.sendStatus(500);

    }  
  });  
 
});
router.post('/login', function(req,res){
  console.log(req.body)
  var name = req.body.Name;
  var employeeid = req.body.Employee_id;
  var password1 = req.body.password
  signup.findOne({"username":name,"employee_id":employeeid,"password":password1},function(err,docs){
  	if(docs){
  		delete docs.password
  		
  		//console.log(docs)
  		req.Session.user = docs
  		//console.log(req.Session.user)
  		res.redirect('/page')

  	}
  	else{
  		console.log(err)
  	}
  })
  
});
router.post('/Email', function(req,res){
  var email = req.body.Email;
  console.log(req.body.Email);
  var newpassword = randomstring.generate(5);
  console.log(newpassword);
  signup.update({"Email":email},{$set:{"password":newpassword}})
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'sruthinunna100@gmail.com',
      pass: 'sruthi@sruthi'
    }
  });

  var mailOptions = {
    from: 'Technicalhub',
    to: Email,
    subject: 'New password',
    text: 'your new password is'+newpassword
  };

  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent');
    }
  });
});
router.get('/logout',function(req,res){
	req.Session.reset()
	res.redirect('/login')
})
module.exports = router;

